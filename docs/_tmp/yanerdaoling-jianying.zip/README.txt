此包为 FrameRally 剪映兼容导出；将 media 导入剪映时间线，或按 draft_content.json 顺序排列。

说明：
- media/ 目录下为各镜头视频文件（shot_001.mp4 …）
- draft_content.json 为简易时间线元数据（非 pyjianyingdraft 原样草稿）
- 请在剪映中手动导入并按 clips 顺序排列
